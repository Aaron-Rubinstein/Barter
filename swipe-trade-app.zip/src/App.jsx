// Replace this content with your actual App.jsx implementation
const App = () => {
  return <div>Hello Swipe Trade</div>;
};

export default App;
